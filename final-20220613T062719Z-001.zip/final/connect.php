<!--
********************************************
** Nom: Yvetot                            **
** Prénom: Quentin                        **
** Date de création: 07/03/2022           **
** Dernière modification: Moi, 03/06/2022 **
********************************************
-->
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Acces BDD</title>
</head>
<body>
<META http-EQUIV="Refresh" CONTENT="1; url=http://172.20.2.130/phpmyadmin"> <!-- rafraichi la page apres 0.1 seconde qui apres redirige vers le lien -->
<center><img border="1" src="./images/chargement.gif"></center>
</body>
</html>