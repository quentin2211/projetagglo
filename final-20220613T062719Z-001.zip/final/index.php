<!--
********************************************
** Nom: Yvetot                            **
** Prénom: Quentin                        **
** Date de création: 02/03/2022           **
** Dernière modification: Moi, 03/06/2022 **
********************************************
-->
<!DOCTYPE html> 
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" type="text/css" href="style.css">
	<title>Agglo'Bus</title> 
</head>

	<body>
		<div class="imgtrain">
			<div>
				<div><a href="BATTERIES.php"><img src="./images/ptittrain.png" width="650" height="=850"></a></div>
			</div>
	</body>
</html>